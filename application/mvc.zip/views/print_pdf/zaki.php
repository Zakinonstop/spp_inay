<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2 align='center'>Laporan Pembayaran SPP</h2>
<hr>

<h3 align='left'>Tahun : 2022</h3>
<h3 align='left'>Kamar : Umar 1</h3>

<div class="row" style="display : flex;flex-wrap: nowrap;background-color: DodgerBlue;">
  <div class="col" style="margin: 10px;" >
    <table border="1" >
      <td>1</td>
    </table>

    <table border="1" style="margin: 10px;">
      <td>2</td>
    </table>
  </div>
</div>

<div class="row">
  <div class="column">
   <table border="1">
      <tr>
        <th>No</th>
        <th>Nama</th>
      </tr>
      <tr>
        <td>1</td>
        <td>Smith</td>
      </tr>
      <tr>
        <td>2</td>
        <td>Stark</td>
      </tr>
      <tr>
        <td>3</td>
        <td>Pogba</td>
      </tr>
    </table>
  </div>

  <div class="column">
   <table>
      <tr>
        <th>Januari</th>
        
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>

  <div class="column">
   <table>
      <tr>
        <th>Februari</th>
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>

  <div class="column">
   <table>
      <tr>
        <th>Maret</th>
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>

  <div class="column">
   <table>
      <tr>
        <th>April</th>
        
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>

  <div class="column">
   <table>
      <tr>
        <th>Mei</th>
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>

  <div class="column">
   <table>
      <tr>
        <th>Juni</th>
        
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>

  <div class="column">
   <table>
      <tr>
        <th>Juli</th>
        
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>

  <div class="column">
   <table>
      <tr>
        <th>Agustus</th>
        
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>
  
  <div class="column">
   <table>
      <tr>
        <th>September</th>
        
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>
  <div class="column">
   <table>
      <tr>
        <th>Oktober</th>
        
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>
  <div class="column">
   <table>
      <tr>
        <th>November</th>
        
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>
  <div class="column">
   <table>
      <tr>
        <th>Desember</th>
        
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>
  <div class="column">
   <table>
      <tr>
        <th>Keterangan</th>
        
      </tr>
      <tr>
        <td>Belly</td>
      </tr>
      <tr>
        <td>Eva</td>
      </tr>
      <tr>
        <td>Diena</td>
      </tr>
    </table>
  </div>

</div>
<br><br>
        <h4 align='right'>Bendahara</h4><br><br>
        <h4 align='right'>Zaki Nafi</h4>


</body>
</html>
